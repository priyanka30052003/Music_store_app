import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable, Observer } from 'rxjs';
import { Admin } from './admin';
import { Payment } from './payment';
import { Product } from './product';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  constructor(private httpClient: HttpClient, private route: ActivatedRoute) { }

  public viewAnuragFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/anurag");
  }
  public viewBtsFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/bts");
  }
  /*public viewCategoryFromRemote(category: String): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/"+category);
    }*/

  public viewsidFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/sid");
  }
  public viewselenaFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/selena");
  }
  public viewlataFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/lata");
  }
  public viewsujathaFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/sujatha");
  }
  public viewashwathFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/ashwath");
  }
  public viewshreyaFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/shreya");
  }


  public viewPopFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/pop");
  }
  public viewMelodyFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/melody");
  }

  public viewHipHopFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/hiphop");
  }
  public viewWorkoutFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/workout");
  }
  public viewChillFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/chill");
  }
  public viewRomanceFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/romance");
  }
  public viewDevotionalFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/devotional");
  }
  public viewClassicFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/classic");
  }

  public viewDrumsetFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/drumset");
  }
  public viewPianoFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/piano");
  }
  public viewGuitarFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/guitar");
  }
  public viewTamilFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/tamil");
  }
  public viewEnglishFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/english");
  }
  public viewHindiFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/hindi");
  }



  public viewMalayalamFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/malayalam");
  }
  public viewTeluguFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/telugu");
  }
  public viewKanadaFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/kanada");
  }



  public viewGujarathiFromRemote(): Observable<Product[]> {

    return this.httpClient.get<Product[]>("http://localhost:8082/gujarathi");
  }
  public viewKoreanFromRemote(): Observable<Product[]> {





    return this.httpClient.get<Product[]>("http://localhost:8082/korean");
  }
  public viewguitarFromRemote(): Observable<Product[]> {

    return this.httpClient.get<Product[]>("http://localhost:8082/guitar");
  }
  public viewpianoFromRemote(): Observable<Product[]> {

    return this.httpClient.get<Product[]>("http://localhost:8082/piano");
  }
  public viewdrumsetFromRemote(): Observable<Product[]> {

    return this.httpClient.get<Product[]>("http://localhost:8082/drumset");
  }



  public loginUserFromRemote(user: User): Observable<Object> {
    return this.httpClient.post("http://localhost:8082/login", user);
  }
  public paymentUserFromRemote(payment: Payment): Observable<Object> {
    return this.httpClient.post("http://localhost:8082/payment",payment);
  }
  public loginAdminFromRemote(admin: Admin): Observable<Object> {
    return this.httpClient.post("http://localhost:8082/login1",admin);
  }
  public registerUserFromRemote(user: User): Observable<Object> {
    return this.httpClient.post("http://localhost:8082/", user);

  }
  public viewUserFromRemote(): Observable<User[]> {
    return this.httpClient.get<User[]>("http://localhost:8082/vuuser");

  }
  public viewProductFromRemote(): Observable<Product[]> {
    return this.httpClient.get<Product[]>("http://localhost:8082/vuprod");

  }
 
  public addProd(product: Product): Observable<Object> {
    return this.httpClient.post("http://localhost:8082/addprod", product);
  }
  getProductById(id: number): Observable<Product> {
    return this.httpClient.get<Product>("http://localhost:8082/addprod/" + id);
  }
  /*getCategoryById(category: String): Observable<Product>{
    return this.httpClient.get<Product>("http://localhost:8082/"+category);
  }*/
  public updateProduct(id: number, product: Product): Observable<Object> {
    return this.httpClient.put("http://localhost:8082/addprod/" + id, product);
  }
  deleteProduct(id: number): Observable<Object>{
    return this.httpClient.delete("http://localhost:8082/addprod/" + id);
  }
}