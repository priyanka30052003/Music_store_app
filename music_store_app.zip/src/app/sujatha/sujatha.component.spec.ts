import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SujathaComponent } from './sujatha.component';

describe('SujathaComponent', () => {
  let component: SujathaComponent;
  let fixture: ComponentFixture<SujathaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SujathaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SujathaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
