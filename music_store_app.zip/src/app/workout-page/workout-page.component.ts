import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-workout-page',
  templateUrl: './workout-page.component.html',
  styleUrls: ['./workout-page.component.css']
})
export class WorkoutPageComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }

  products1!: Product[];

  constructor( private cartService: CartServiceService,private _service: RegisterService) { }

  ngOnInit(): void {
    this.getWorkout();
  }
  private getWorkout(){
    
    this._service.viewWorkoutFromRemote().subscribe(data =>{
      this.products1=data;
  
    });

}
}
