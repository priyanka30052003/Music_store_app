import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import {HttpClientModule} from '@angular/common/http';
import { HomepageComponent } from './homepage/homepage.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { ArtistComponent } from './artist/artist.component';
import { LanguageComponent } from './language/language.component';
import { GenreComponent } from './genre/genre.component';
import { SidComponent } from './sid/sid.component';
import { AnuragComponent } from './anurag/anurag.component';
import { ShreyaComponent } from './shreya/shreya.component';
import { BtsComponent } from './bts/bts.component';
import { SujathaComponent } from './sujatha/sujatha.component';
import { SelenaComponent } from './selena/selena.component';
import { AshwathComponent } from './ashwath/ashwath.component';
import { LataComponent } from './lata/lata.component';
import { TamilComponent } from './tamil/tamil.component';
import { TeluguComponent } from './telugu/telugu.component';
import { EnglishComponent } from './english/english.component';
import { MalayalamComponent } from './malayalam/malayalam.component';
import { GujaratiComponent } from './gujarati/gujarati.component';
import { KanadaComponent } from './kanada/kanada.component';
import { KoreanComponent } from './korean/korean.component';
import { PopComponent } from './pop/pop.component';
import { MelodyComponent } from './melody/melody.component';
import { DevotionalComponent } from './devotional/devotional.component';
import { HiphopComponent } from './hiphop/hiphop.component';
import { GuitarComponent } from './guitar/guitar.component';
import { PianoComponent } from './piano/piano.component';

import { WorkoutPageComponent } from './workout-page/workout-page.component';

import { RomanceComponent } from './romance/romance.component';
import { DrumComponent } from './drum/drum.component';
import { ClassicComponent } from './classic/classic.component';
import { CartComponent } from './cart/cart.component';
import { ProductdetailComponent } from './productdetail/productdetail.component';
import { UserdetailComponent } from './userdetail/userdetail.component';
import { AddproductComponent } from './addproduct/addproduct.component';

import { EditProdComponent } from './edit-prod/edit-prod.component';
import { SelectPageComponent } from './select-page/select-page.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    HomepageComponent,
    AdminPageComponent,
    LoginPageComponent,
    ArtistComponent,
    LanguageComponent,
    GenreComponent,
    SidComponent,
    AnuragComponent,
    ShreyaComponent,
    BtsComponent,
    SujathaComponent,
    SelenaComponent,
    AshwathComponent,
    LataComponent,
    TamilComponent,
    TeluguComponent,
    EnglishComponent,
    MalayalamComponent,
    GujaratiComponent,
    KanadaComponent,
    KoreanComponent,
    PopComponent,
    MelodyComponent,
    WorkoutPageComponent,
    DevotionalComponent,
    HiphopComponent,
    GuitarComponent,
    RomanceComponent,
    DrumComponent,
    ClassicComponent,
    CartComponent,
    ProductdetailComponent,
    UserdetailComponent,
    AddproductComponent,
    PianoComponent,
    EditProdComponent,
     SelectPageComponent,
     AdminLoginComponent,
     PaymentComponent,
  

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'Home-page', component: HomepageComponent },
      {path: 'payment', component: PaymentComponent },

      {path: 'login1', component: AdminLoginComponent },
      {path: 'select', component: SelectPageComponent },
      {path: 'update-employee/:id', component: EditProdComponent },
      {path: 'addprod', component: AddproductComponent },
      {path: 'vuuser', component: ProductdetailComponent },
      {path: 'vuprod', component: UserdetailComponent },
      {path: 'register', component: RegisterUserComponent},
      {path: 'admin', component: AdminPageComponent},
      {path:'login', component: LoginPageComponent},
      {path:'artist', component: ArtistComponent},
      {path:'genre', component: GenreComponent},
      {path:'language', component: LanguageComponent},
      {path:'sujatha', component:SujathaComponent},
      {path:'selena', component:SelenaComponent},
      {path:'sid', component:SidComponent},
      {path:'Ashwath', component:AshwathComponent},
      {path:'pop', component:PopComponent},
      {path:'bts', component:BtsComponent},
      {path:'anurag', component:AnuragComponent},
      {path:'shreya', component:ShreyaComponent},
      {path:'guitar', component:GuitarComponent},
      {path:'lata', component: LataComponent},
      {path:'piano', component: PianoComponent},
      {path:'tamil', component: TamilComponent},
      {path:'telugu', component: TeluguComponent},
      {path:'english', component: EnglishComponent},
      {path:'kanada', component: KanadaComponent},
      {path:'workout', component:WorkoutPageComponent},
      {path:'gujarathi', component:GujaratiComponent},
      {path:'melody', component:MelodyComponent},
      {path:'devotional', component:DevotionalComponent},
      {path:'malayalam', component:MalayalamComponent},
      {path:'korean', component:KoreanComponent},
      {path:'romance', component:RomanceComponent},
      {path:'classic', component:ClassicComponent},
      {path:'hiphop', component:HiphopComponent},
      {path:'drumset', component:DrumComponent},
      {path:'cart', component:CartComponent}

      
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }