import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-romance',
  templateUrl: './romance.component.html',
  styleUrls: ['./romance.component.css']
})
export class RomanceComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[];





  constructor(private cartService: CartServiceService,private _service: RegisterService) { }
  
  
  
  
  
  ngOnInit(): void {
  this.getromance();
  }
  private getromance(){
  
  
  
  this._service.viewRomanceFromRemote().subscribe(data =>{
  this.products1=data;
  
  
  
  });
  
  
  
  
  
  }
  
  
}
