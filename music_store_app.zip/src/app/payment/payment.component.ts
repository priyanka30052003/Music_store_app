import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../payment';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  payment= new Payment();

  constructor(private _service: RegisterService,private _router:Router) { }

  ngOnInit(){
  }

  paymentUser(){
    this._service.paymentUserFromRemote(this.payment).subscribe(data=>{
      alert("Successfully paid")
      this._router.navigate(['Home-page'])
     },error=>alert("error"));
    
}}
