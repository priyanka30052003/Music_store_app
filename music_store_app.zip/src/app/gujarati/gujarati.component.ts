import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-gujarati',
  templateUrl: './gujarati.component.html',
  styleUrls: ['./gujarati.component.css']
})
export class GujaratiComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor(private cartService: CartServiceService,
    private _service: RegisterService) { } ngOnInit(): void {
    this.getgujarathi();
    }
    private getgujarathi(){
    this._service.viewGujarathiFromRemote().subscribe(data =>{
    this.products1=data;
    });}
}
