import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CartServiceService } from '../cart-service.service';
import { Product } from '../product';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-ashwath',
  templateUrl: './ashwath.component.html',
  styleUrls: ['./ashwath.component.css']
})
export class AshwathComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[];

  constructor( private cartService: CartServiceService,
    private _service: RegisterService) { }

  ngOnInit(): void {
    this.getashwath();
  }
  private getashwath(){
    
    this._service.viewashwathFromRemote().subscribe(data =>{
      this.products1=data;
  
    });

}

}

