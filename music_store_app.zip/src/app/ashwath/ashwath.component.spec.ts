import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AshwathComponent } from './ashwath.component';

describe('AshwathComponent', () => {
  let component: AshwathComponent;
  let fixture: ComponentFixture<AshwathComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AshwathComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AshwathComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
