import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';

@Component({
  selector: 'app-classic',
  templateUrl: './classic.component.html',
  styleUrls: ['./classic.component.css']
})
export class ClassicComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[];

  constructor( private cartService: CartServiceService,private _service: RegisterService) { }

  ngOnInit(): void {
    this.getclassic();
  }
  private getclassic(){
    
    this._service.viewClassicFromRemote().subscribe(data =>{
      this.products1=data;
  
    });

}

}
