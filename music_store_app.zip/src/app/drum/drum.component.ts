import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';

@Component({
  selector: 'app-drum',
  templateUrl: './drum.component.html',
  styleUrls: ['./drum.component.css']
})
export class DrumComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor(
    private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getdrum();
    }
    private getdrum(){
    this._service.viewDrumsetFromRemote().subscribe(data =>{
    this.products1=data;
    });}

}
