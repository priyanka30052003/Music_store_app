import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KanadaComponent } from './kanada.component';

describe('KanadaComponent', () => {
  let component: KanadaComponent;
  let fixture: ComponentFixture<KanadaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KanadaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KanadaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
