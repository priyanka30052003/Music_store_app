import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-sid',
  templateUrl: './sid.component.html',
  styleUrls: ['./sid.component.css']
})
export class SidComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; 
  constructor(private _service: RegisterService,private router: Router,private route: ActivatedRoute,
    private cartService: CartServiceService) { } 
  ngOnInit(): void {
    this.getsid();
    }
    private getsid(){
    this._service.viewsidFromRemote().subscribe(data =>{
    this.products1=data;
    });
  }
  

}
