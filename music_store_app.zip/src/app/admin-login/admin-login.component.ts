import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  admin= new Admin();

  constructor(private _service: RegisterService,private _router:Router) { }

  ngOnInit(){
  }

  loginAdmin(){
    this._service.loginAdminFromRemote(this.admin).subscribe(data=>{
      alert("Successfully logged in")
      this._router.navigate(['admin'])
     },error=>alert("error"));
    
}}

