export class Admin {
    id!:Number;
    userId!:string;

    password!:string;

  }