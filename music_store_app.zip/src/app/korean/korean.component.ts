import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-korean',
  templateUrl: './korean.component.html',
  styleUrls: ['./korean.component.css']
})
export class KoreanComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor( private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getkorean();
    }
    private getkorean(){
    this._service.viewKoreanFromRemote().subscribe(data =>{
    this.products1=data;
    });}
}
