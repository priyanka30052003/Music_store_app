import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-shreya',
  templateUrl: './shreya.component.html',
  styleUrls: ['./shreya.component.css']
})
export class ShreyaComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }

  products1!: Product[]; 
  constructor(private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getshreya();
    }
    private getshreya(){
    this._service.viewshreyaFromRemote().subscribe(data =>{
    this.products1=data;
    });}

}
