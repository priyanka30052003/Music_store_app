import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-artist',
  templateUrl: './artist.component.html',
  styleUrls: ['./artist.component.css']
})
export class ArtistComponent implements OnInit {
  category!: String
  products!: Product[];
  product= new Product();
  constructor(private _service: RegisterService,private router: Router,private route: ActivatedRoute,) { }

  ngOnInit(): void {
    /*this.category = this.route.snapshot.params['category'];
    this._service.getCategoryById(this.category).subscribe(data => {
      this.product = data;
    }, error => console.log(error));
    this.getCategory();
  }
  private getCategory(){
    this._service.viewCategoryFromRemote(this.category).subscribe(data =>{
      this.products=data;
    });
  }
  categoryDetails(category: String){
    this.router.navigate(['', category]);*/
  }

}
