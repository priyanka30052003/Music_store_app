import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';

import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-anurag',
  templateUrl: './anurag.component.html',
  styleUrls: ['./anurag.component.css']
})
export class AnuragComponent implements OnInit {

 addToCart(product: Product) {
  this.cartService.addToCart(product);
  window.alert('Your product has been added to the cart!');
}
products1!: Product[];
  constructor( private cartService: CartServiceService,private _service: RegisterService) { }

  ngOnInit(): void {
    this.getAnurag();
  }
  private getAnurag(){
    
    this._service.viewAnuragFromRemote().subscribe(data =>{
      this.products1=data;
  
    });

}}
