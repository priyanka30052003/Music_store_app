import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { User } from '../user';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  user= new User();

  constructor(private _service: RegisterService,private _router:Router) { }

  ngOnInit(){
  }

  loginUser(){
    this._service.loginUserFromRemote(this.user).subscribe(data=>{
      alert("Successfully logged in")
      this._router.navigate(['Home-page'])
     },error=>alert("error"));
    
}}
