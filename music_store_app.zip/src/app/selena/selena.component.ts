import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-selena',
  templateUrl: './selena.component.html',
  styleUrls: ['./selena.component.css']
})
export class SelenaComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor(private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getselena();
    }
    private getselena(){
    this._service.viewselenaFromRemote().subscribe(data =>{
    this.products1=data;
    });}
}
