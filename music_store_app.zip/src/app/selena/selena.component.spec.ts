import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelenaComponent } from './selena.component';

describe('SelenaComponent', () => {
  let component: SelenaComponent;
  let fixture: ComponentFixture<SelenaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelenaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelenaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
