
import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Product } from '../product';
import { ActivatedRoute, Router } from '@angular/router'; 
@Component({
  selector: 'app-update-product',
  templateUrl: './edit-prod.component.html',
  styleUrls: ['./edit-prod.component.css']
})
export class EditProdComponent implements OnInit {
    id!: number;
  product: Product = new Product();

  constructor(private _service: RegisterService,
    private route: ActivatedRoute,
    private router: Router) { } 
    ngOnInit(): void {
      this.id = this.route.snapshot.params['id']; 
      this._service.getProductById(this.id).subscribe(data => {
        this.product = data;
      }, error => console.log(error));
    } onSubmit() {
      this._service.updateProduct(this.id, this.product).subscribe(data => {
        this.goToproductList();
      }
        , error => console.log(error));
    }
  goToproductList() {
    this.router.navigate(['/vuprod']);
  }
}


