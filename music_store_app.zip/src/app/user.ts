

export class User {
    id!:Number;
    name!:string;
    userId!:string;

    password!:string;

  }