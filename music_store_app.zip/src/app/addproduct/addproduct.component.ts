import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  product: Product = new Product();
  constructor(private _service: RegisterService,private _router:Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
  }
  saveProd(){
    this._service.addProd(this.product).subscribe(data =>{
      console.log(this.route);
      this._router.navigate(['/vuprod'])

    },
    error => console.log(error));
  }
  onSubmit(){
    console.log(this.product);
    this.saveProd();

  }

}
