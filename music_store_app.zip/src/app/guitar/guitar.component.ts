import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';

import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-guitar',
  templateUrl: './guitar.component.html',
  styleUrls: ['./guitar.component.css']
})
export class GuitarComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor( private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getguitar();
    }
    private getguitar(){
    this._service.viewGuitarFromRemote().subscribe(data =>{
    this.products1=data;
    });}

}
