import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';
import { User } from '../user';

@Component({
  
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  user =new User();

  constructor(private _service: RegisterService,private _router:Router) { }

  ngOnInit(): void {
  }

  userRegister(){
    console.log(this.user);
    this._service.registerUserFromRemote(this.user).subscribe(data=>{
     alert("Successfully User is registered,Now You will be redirected to Login page")
     this._router.navigate(['login'])
    },error=>alert("Sorry User not register"));
  }

}