import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-malayalam',
  templateUrl: './malayalam.component.html',
  styleUrls: ['./malayalam.component.css']
})
export class MalayalamComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor( private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getmalayalam();
    }
    private getmalayalam(){
    this._service.viewMalayalamFromRemote().subscribe(data =>{
    this.products1=data;
    });}

}
