import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { User } from '../user';

@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {
  users!: User[];
  constructor(private _service: RegisterService) { }

  ngOnInit(): void {
    this.getUsers();
  }
  private getUsers(){
    this._service.viewUserFromRemote().subscribe(data =>{
      this.users=data;
    });
  }

}
