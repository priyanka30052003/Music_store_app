export class Payment {
    id!:number;
    name!:string;
    phnnum!:string;
    cardnum!:string;
    cvv!:string;
}
