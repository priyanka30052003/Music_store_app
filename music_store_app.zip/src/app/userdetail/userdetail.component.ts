import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {

  products!: Product[];

  constructor(private _service: RegisterService,private router: Router) { }

  ngOnInit(): void {
    this.getProducts();
  }
    
  
  private getProducts(){
    this._service.viewProductFromRemote().subscribe(data =>{
      this.products=data;
    });
  }
  productDetails(id: number){
      this.router.navigate(['addprod', id]);
    }
  

  updateProduct(id: number){
    this.router.navigate(['update-employee',id])
  }
  deleteProduct(id: number){
    this._service.deleteProduct(id).subscribe( data => {
      console.log(data);
      this.getProducts();
    })
  }

}



