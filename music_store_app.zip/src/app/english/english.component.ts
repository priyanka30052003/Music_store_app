import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-english',
  templateUrl: './english.component.html',
  styleUrls: ['./english.component.css']
})
export class EnglishComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[]; constructor(private cartService: CartServiceService,private _service: RegisterService) { } ngOnInit(): void {
    this.getenglish();
    }
    private getenglish(){
    this._service.viewEnglishFromRemote().subscribe(data =>{
    this.products1=data;
    });}

}
