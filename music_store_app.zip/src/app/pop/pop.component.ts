import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { RegisterService } from '../register.service';
import { CartServiceService } from '../cart-service.service';
@Component({
  selector: 'app-pop',
  templateUrl: './pop.component.html',
  styleUrls: ['./pop.component.css']
})
export class PopComponent implements OnInit {
  addToCart(product: Product) {
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }
  products1!: Product[];





  constructor( private cartService: CartServiceService,private _service: RegisterService) { }
  
  
  
  
  
  ngOnInit(): void {
  this.getpop();
  }
  private getpop(){
  
  
  
  this._service.viewPopFromRemote().subscribe(data =>{
  this.products1=data;
  
  
  
  });
  
  
  
  
  
  }

}
